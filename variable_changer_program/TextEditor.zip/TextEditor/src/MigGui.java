
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;


import net.miginfocom.swing.MigLayout;

public class MigGui {	
	public static void main(String[] args) {
				
		final Editor editor = new Editor();
		File[] files;
				
		JFrame frame = new JFrame("File Editor");
		frame.setSize(200, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();		
		panel.setBorder(BorderFactory.createTitledBorder("file  "));
		frame.add(panel);		
		panel.setLayout(new MigLayout("","[]10[] ", "[] [] []" ));
		
		JLabel FindLabel = new JLabel("Find");		
		JLabel ReplaceLabel = new JLabel("Replace With");
		JLabel ChangesLabel = new JLabel("Changes Made to file(s)");		
				
				
		JTextField FilePathTextField = new JTextField(20); 
		final JTextField ReplaceTextField = new JTextField(20);
		final JTextField FindTextField = new JTextField(20);
		
		final JTextArea ChangesTextArea = new JTextArea(30,20);
		ChangesTextArea.setBorder(BorderFactory.createEtchedBorder());
		
		JButton openBtn = new JButton("Select Files");		
		JButton executeBtn = new JButton("Execute");		
		
		panel.add(openBtn,"left, sg 1, split 2");
		panel.add(FilePathTextField,"pushx, growx, wrap");		
		panel.add(FindLabel,"left, sg 1, split 2");
		panel.add(FindTextField,"push, growx, wrap");		
		panel.add(ReplaceLabel,"left, sg 1, split 3");
		panel.add(ReplaceTextField,"pushx, growx, wrap");
		panel.add(executeBtn,"wrap");		
		panel.add(ChangesLabel,"wrap, sg 1, split 2");		
		panel.add(ChangesTextArea," wrap, wrap, wrap");
		
		frame.pack();
		frame.setLocation(300,300);
		frame.setSize(450, 400);		
		frame.setVisible(true);
				
		openBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				editor.chooseFiles();				
			}
		});
		
		while(editor.filesChoosen()==false) //Wait here until files are selected
		{					
		}
		
		files=editor.getFiles();
		String file_path =files[0].getParent();
		FilePathTextField.setText(files.length + " File(s) Seleceted. PATH: " + file_path);										
		
		executeBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
				String find = FindTextField.getText();
				String replace = ReplaceTextField.getText();
				String changes = editor.execute(find,replace);
				ChangesTextArea.setText(changes);
			}
		});
										
	}

}
