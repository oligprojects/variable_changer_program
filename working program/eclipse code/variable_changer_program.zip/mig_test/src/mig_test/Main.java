package mig_test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.io.*;
import java.util.ArrayList;

import net.miginfocom.swing.MigLayout;

//program to open lots of files and replaces a value
//hold ctrl to open multiable files in file viewer

//Created by oliver greaneys team GMIT



public class Main {

	private static File[] files;
	private static String folder_location;
	private static String string_to_find = "int x = 5;"; // origionl value show in gui
	private static String string_to_replace = "int x = 100;"; // the new value show in gui

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		JFrame frame = new JFrame("File Editor");
		frame.setSize(200, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		panel.setBorder(BorderFactory.createTitledBorder("file  "));
		frame.add(panel);
		panel.setLayout(new MigLayout("", "[]10[] ", "[] [] []"));

		JLabel FindLabel = new JLabel("Find");
		JLabel ReplaceLabel = new JLabel("Replace With");
		JLabel ChangesLabel = new JLabel("Changes Made to file(s)");

		final JTextField FilePathTextField = new JTextField(20);
		final JTextField ReplaceTextField = new JTextField(20);
		final JTextField FindTextField = new JTextField(20);

		final JTextArea ChangesTextArea = new JTextArea(30, 20);
		ChangesTextArea.setBorder(BorderFactory.createEtchedBorder());

		JButton openBtn = new JButton("Select Files");
		JButton executeBtn = new JButton("Execute");

		panel.add(openBtn, "left, sg 1, split 2");
		panel.add(FilePathTextField, "pushx, growx, wrap");
		panel.add(FindLabel, "left, sg 1, split 2");
		panel.add(FindTextField, "push, growx, wrap");
		panel.add(ReplaceLabel, "left, sg 1, split 3");
		panel.add(ReplaceTextField, "pushx, growx, wrap");
		panel.add(executeBtn, "wrap");
		panel.add(ChangesLabel, "wrap, sg 1, split 2");
		panel.add(ChangesTextArea, " wrap, wrap, wrap");

		frame.pack();
		frame.setLocation(300, 300);
		frame.setSize(450, 400);
		frame.setVisible(true);

		openBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				JFileChooser chooser = new JFileChooser();
				chooser.setMultiSelectionEnabled(true); // open multable files using ctrl
				chooser.showOpenDialog(null);
				files = chooser.getSelectedFiles();
				folder_location = chooser.getCurrentDirectory().toString(); // show in gui

				// update gui
				FilePathTextField.setText(folder_location);
				FindTextField.setText(string_to_find);
				ReplaceTextField.setText(string_to_replace);

				// Retrieve the selected files.
				files = chooser.getSelectedFiles();

			}
		});

		executeBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				// get data from gui
				string_to_find = FindTextField.getText();
				string_to_replace = ReplaceTextField.getText();

				// setup vars
				ArrayList<String> lines = new ArrayList<String>();
				int count = 0;
				int small_count = 0;
				String line = null;

				// loop threw files and do the work
				for (File value : files) {

					try {
						File the_file = value;
						FileReader file = new FileReader(the_file);
						BufferedReader br = new BufferedReader(file);

						// read
						while ((line = br.readLine()) != null) {
							if (line.contains(string_to_find)) {
								line = line.replace(string_to_find,
										string_to_replace);
								count++;
								small_count++;

							}
							lines.add(line);

						}
						ChangesTextArea.append(the_file.getName() + ": " 
						+ small_count + " lines changed" + "\n");
						small_count = 0;
						file.close();
						br.close();

						// write
						FileWriter fw = new FileWriter(the_file);
						BufferedWriter bw = new BufferedWriter(fw);

						for (String s : lines) {
							bw.write(s + "\n");
						}

						bw.flush();
						bw.close();
						lines.clear();

					} catch (Exception ex) {
						ex.printStackTrace();
					}

				}
				String amount_lines_changed = ("total amount of lines changed: " + count + "\n"); // in gui

				ChangesTextArea.append(amount_lines_changed);

			}
		});

	}

}
