package mig_test;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import java.io.*;
import java.util.ArrayList;

import net.miginfocom.swing.MigLayout;

//program to open lots of files and replaces a value
//hold ctrl to open multiable files in file viewer

//Created by oliver greaneys team GMIT



public class Main {

	private static File[] files;
	private static String folder_location;
	private static String string_to_find = "int x = 5;"; // origionl value show in gui
	private static String string_to_replace = "int x = 100;"; // the new value show in gui

	public static void main(String[] args) {
		
        
		
		
		// TODO Auto-generated method stub
		JTabbedPane jtp = new JTabbedPane();

		JFrame frame = new JFrame("File Editor");
		frame.add(jtp);
		
		frame.setSize(200, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		JPanel panel = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		panel.setBorder(BorderFactory.createTitledBorder("file  "));
		//frame.add(panel);
		panel.setLayout(new MigLayout("", "[]12[] ", "[] [] []"));
		panel3.setLayout(new MigLayout("", "[]12[] ", "[] [] []"));
		JLabel FindLabel = new JLabel("Find");
		JLabel ReplaceLabel = new JLabel("Replace With");
		JLabel ChangesLabel = new JLabel("Changes Made to file(s)");
		JLabel tipsLabel = new JLabel("Usefull Tips");
		
		final JTextField FilePathTextField = new JTextField(20);
		final JTextField ReplaceTextField = new JTextField(20);
		final JTextField FindTextField = new JTextField(20);

		final JTextArea ChangesTextArea = new JTextArea(300, 200);
		final JTextArea tipsTextArea = new JTextArea(30, 20);
		ChangesTextArea.setBorder(BorderFactory.createEtchedBorder());
		tipsTextArea.setBorder(BorderFactory.createEtchedBorder());
		JScrollPane scroll_window_1 = new JScrollPane(ChangesTextArea);
		
		
		JButton openBtn = new JButton("Select Files");
		JButton executeBtn = new JButton("Execute");
		JButton infoBtn = new JButton("Info");
		
		
		panel.add(openBtn, "left, sg 1, split 2");
		panel.add(FilePathTextField, "pushx, growx, wrap");
		panel.add(FindLabel, "left, sg 1, split 2");
		panel.add(FindTextField, "push, growx, wrap");
		panel.add(ReplaceLabel, "left, sg 1, split 3");
		panel.add(ReplaceTextField, "pushx, growx, wrap");
		panel.add(executeBtn, "wrap");
		panel3.add(ChangesLabel,  "left, sg 1 , split 2");
		panel3.add(scroll_window_1,  " growx,growx, wrap");
		panel.add(tipsLabel, "right, growx, wrap");
		//panel.add(ChangesTextArea, " wrap, wrap, wrap");
		//panel3.add(scroll_window_1,  " left, growx, wrap");
		panel.add(tipsTextArea, " right, growx, wrap");
		panel.add(infoBtn, " growx, growx, growx");
		
		JLabel label1 = new JLabel();
		JLabel label2 = new JLabel();
		JLabel label3 = new JLabel();
		
		
		
        label1.setText("Taking the tedium out of editing meta data in multiple files");
        label2.setText("Simply chose your file or files select what you would like to change\n");
        label3.setText("and what you would like to replace it with and..... its done");
        panel2.add(label1);
        panel2.add(label2);
        panel2.add(label3);
		
		frame.pack();
		frame.setLocation(300, 300);
		frame.setSize(450, 400);
		frame.setVisible(true);
		
		
        jtp.addTab("Variable Changer", panel);
        jtp.addTab("Results", panel3);
        jtp.addTab("Instructions", panel2);

		
		tipsTextArea.setText("hold down ctrl to select multiable files.\n");
		tipsTextArea.append("ctrl + a to select all files.");
		
		openBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {

				JFileChooser chooser = new JFileChooser();
				chooser.setMultiSelectionEnabled(true); // open multable files using ctrl
				chooser.showOpenDialog(null);
				files = chooser.getSelectedFiles();
				folder_location = chooser.getCurrentDirectory().toString(); // show in gui
				int filecount = files.length;
				
				// update gui
				FilePathTextField.setText(folder_location + "\\(" + filecount + " files selected)");
				FindTextField.setText(string_to_find);
				ReplaceTextField.setText(string_to_replace);

				// Retrieve the selected files.
				files = chooser.getSelectedFiles();

			}
		});

		
		infoBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
		
				String st="Program created by Oliver,"
						+ "Shane and Declan.\nGithub: "
						+ "https://github.com/oligprojects\n"
						+ "This program is in the beta stage of developemnt.\n"
						+ "_______________________________________";
				JOptionPane.showMessageDialog(null,st);
			}
			});
		
		executeBtn.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent arg0) {

				// get data from gui
				string_to_find = FindTextField.getText();
				string_to_replace = ReplaceTextField.getText();

				// setup vars
				ArrayList<String> lines = new ArrayList<String>();
				int count = 0;
				int small_count = 0;
				String line = null;

				if(files != null){
				// loop threw files and do the work
				for (File value : files) {

					try {
						File the_file = value;
						FileReader file = new FileReader(the_file);
						BufferedReader br = new BufferedReader(file);

						// read
						while ((line = br.readLine()) != null) {
							if (line.contains(string_to_find)) {
								line = line.replace(string_to_find,
										string_to_replace);
								count++;
								small_count++;

							}
							lines.add(line);

						}
						ChangesTextArea.append(the_file.getName() + ": " 
						+ small_count + " lines changed" + "\n");
						small_count = 0;
						file.close();
						br.close();

						// write
						FileWriter fw = new FileWriter(the_file);
						BufferedWriter bw = new BufferedWriter(fw);

						for (String s : lines) {
							bw.write(s + "\n");
						}

						bw.flush();
						bw.close();
						lines.clear();

					} catch (Exception ex) {
						ex.printStackTrace();
					}

				}
				
				}
				String amount_lines_changed = ("total amount of lines changed: " + count + "\n"); // in gui

				ChangesTextArea.append(amount_lines_changed);

			}
		});

	}
	

}
